<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['Log'] == "ORA") {
    ?>
    <?php
    $error = "";
    if (isset($_POST['Present'])) {
        require 'dbconnect.php';
        $text = $_POST['id'];
        $start = strpos($text, '"');
        $end = strpos($text, ",");
        $name = substr($text, $start + 1, $end - $start - 2);
        $status = "Present";
        $day = date('Y-m-d');
        if ($day == "2018-03-07") {
            $sql = "SELECT DayOne FROM register where UserName='$name'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $state = $row['DayOne'];
                if ($state == "NONE") {
                    $sql = "UPDATE register SET DayOne='$status' WHERE UserName='$name'";
                    if ($conn->query($sql)) {
                        $error = " Day One Attendance - Successfully Updated";
                    } else {
                        $error = "  Please Try Again";
                    }
                } else {
                    $error = " Already Present ";
                }
            }
        } elseif ($day == "2018-03-08") {
            $sql = "SELECT DayTwo FROM register where UserName='$name'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $state = $row['DayTwo'];
                if ($state == "NONE") {

                    $sql = "UPDATE register SET DayTwo='$status' WHERE UserName='$name'";
                    if ($conn->query($sql)) {
                        $error = "   Day Two Attendance - Successfully Updated";
                    } else {
                        $error = "  Please Try Again";
                    }
                } else {
                    $error = " Already Present ";
                }
            }
        }
    }
    ?>
    <!DOCTYPE html>
    <html lang="en">
        <head>
            <link rel="stylesheet" href="docs/style.css">
            <script type="text/javascript" src="docs/adapter.min.js"></script>
            <script type="text/javascript" src="docs/vue.min.js"></script>
            <script type="text/javascript" src="docs/instascan.min.js"></script>
            <?php include 'Style.php' ?>
        </head>
        <body>
            <div id="wrapper">
                <!-- Navigation -->
                <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                    <?php include 'NavBar.php'; ?>
                    <?php include 'Menu.php'; ?>
                    <!-- /.navbar-static-side -->
                </nav>
                <!-- Page Content -->
                <div id="page-wrapper">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <h1 class="page-header">Scan QR CODE - Attendance</h1>
                            </div>  
                        </div> <div class="row">
                            <div id="app" style="background-color:#fff">
                                <div class="col-sm-12 col-md-12 col-lg-6">
                                    <?php if (!empty($error)) { ?>   <div class="alert alert-success alert-dismissable">
                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                            <?php echo $error; ?> </div> <?php } ?>

                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <i class="fa fa-edit fa-fw"></i> Scanned Text
                                        </div>
                                        <!-- /.panel-heading -->
                                        <div class="panel-body">       
                                            <div  >
                                                <section >
                                                    <h2>Camera Name:</h2>
                                                    <div >
                                                        <div v-if="cameras.length === 0" >No cameras found</div >
                                                        <div v-for="camera in cameras">
                                                            <span v-if="camera.id == activeCameraId" :title="formatName(camera.name)" >{{ formatName(camera.name) }}</span>
                                                            <span v-if="camera.id != activeCameraId" :title="formatName(camera.name)">
                                                                <a @click.stop="selectCamera(camera)">{{ formatName(camera.name) }}</a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </section>
                                                <section >
                                                    <form name="import" method="post" action="Attendance.php" enctype="multipart/form-data">
                                                        <h2>Scan Text:</h2>
                                                        <div v-if="scans.length === 0">
                                                            <div >No scans yet</div>
                                                        </div>
                                                        <transition-group name="scans" tag="ul">

                                                            <textarea class="form-control"  name="id" v-for="scan in scans" :key="scan.date" :title="scan.content">{{ scan.content }}</textarea>

                                                        </transition-group>

                                                        <button class="btn btn-warning fa-1x"  name="Present"  /><i class="fa fa-check-square-o"></i>&nbsp;&nbsp;Present</button>
                                                    </form>
                                                </section>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                                <div class="col-sm-12 col-md-12 col-lg-6">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <i class="fa fa-qrcode fa-fw"></i> Scanner
                                        </div>
                                        <!-- /.panel-heading -->
                                        <div class="panel-body">
                                            <div class="preview-container">
                                                <video id="preview"></video>
                                            </div>
                                        </div>
                                        <!-- /.panel-body -->
                                    </div>  
                                </div>
                            </div>
                            <script type="text/javascript" src="docs/app.js"></script>
                        </div>
                    </div>
                    <!-- /.container-fluid -->
                </div>
                <!-- /#page-wrapper -->
            </div>
            <!-- /#wrapper -->
            <?php include 'Script.php' ?>
        </body>
    </html>
    <?php
} else {
    header("location:Index.php");
}?>