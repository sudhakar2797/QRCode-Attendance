<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['Log'] == "ORA") {
    ?>
    <!DOCTYPE html>
    <html lang="en">
        <head>
            <?php include 'Style.php' ?>

            <!-- DataTables CSS -->
            <link href="css/dataTables/dataTables.bootstrap.css" rel="stylesheet">

            <!-- DataTables Responsive CSS -->
            <link href="css/dataTables/dataTables.responsive.css" rel="stylesheet">

            <style>
                #yourBtn{
                    font-family: calibri;
                    width: 250px;
                    -webkit-border-radius: 5px;
                    -moz-border-radius: 5px;
                    text-align: center;
                    background-color: #357ae8;
                    color: white;
                    padding: 14px 20px;
                    margin: 8px 0;
                    border: none;
                    cursor: pointer;
                }
                #yourBtn:hover{
                    background-color: #0000FF;
                }
            </style>
        </head>
        <body>

            <div id="wrapper">

                <!-- Navigation -->
                <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                    <?php include 'NavBar.php'; ?>
                    <?php include 'Menu.php'; ?>
                    <!-- /.navbar-static-side -->
                </nav>

                <!-- Page Content -->
                <div id="page-wrapper">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <h1 class="page-header">Generate QR CODE</h1>
                            </div>
                            <div class="col-sm-12 col-md-12 col-lg-6">
                                <div class="panel panel-default">
                                    <div class="panel-heading">
                                        <i class="fa fa-qrcode fa-fw"></i> Generate QR-Code
                                    </div>
                                    <!-- /.panel-heading -->
                                    <div class="panel-body">
                                        <h4><b>Select .csv File only</b></h4>

                                        <center>

                                            <form name="import" method="post" enctype="multipart/form-data">
                                                <div id="yourBtn" onclick="getFile()"><i class="fa fa-edit"></i>&nbsp;&nbsp;Click To Insert A Data</div>
                                                <div style='height: 0px;width: 0px; overflow:hidden;'><input id="upfile" type="file" name="file" value="upload" onchange="sub(this)" required/></div>
                                                <button class="btn btn-primary fa-1x"  name="Generate"  /><i class="fa fa-gears"></i>&nbsp;&nbsp;Generate</button>
                                            </form>
                                        </center>
                                        <script type="text/javascript">
                                            function getFile() {
                                                document.getElementById("upfile").click();
                                            }
                                            function sub(obj) {
                                                var file = obj.value;
                                                var fileName = file.split("\\");
                                                document.getElementById("yourBtn").innerHTML = fileName[fileName.length - 1];
                                                document.myForm.submit();
                                                event.preventDefault();
                                            }
                                        </script>
                                    </div>
                                    <!-- /.panel-body -->
                                </div>             <!-- /.container-fluid -->
                            </div>
                        </div> <div class="row">

                            <?php
                            if (isset($_POST['Generate'])) {
                                include "generator/qrlib.php";
                                $error = "";
                                $file = $_FILES['file']['tmp_name'];
                                $handle = fopen($file, "r");
                                $handle = fopen($file, "r");
                                $no = 0;
                                while (($filesop = fgetcsv($handle, 1000, ",")) !== false) {


                                    $data = 'NAME:"' . $filesop[0] . '",ABSTRACT CODE : "' . $filesop[1] . '"   TITLE: "' . $filesop[2] . '" COLLEGE: "' . $filesop[3] . '"';
                                    $name = $filesop[0];
                                    $filename = 'QRCODE\\' . $name . '.png';
                                    QRcode::png($data, $filename);
                                    ?>
                                    <div class="col-sm-12 col-md-12 col-lg-3" style="height:230px;"> 
                                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">

                                            <tbody>
                                                <tr class="odd gradeX"><center><img src="<?php echo $filename ?>"/><br><?php echo $no++ . '.' . $filesop[0] ?></center></tr>

                                            </tbody></table></div><?php
                                }
                            }
                            ?>
                            <!-- /.col-lg-12 -->


                            <!-- /.row -->
                        </div>
                        <!-- /.container-fluid -->
                    </div>
                    <!-- /#page-wrapper -->

                </div>
                <!-- /#wrapper -->
                <?php include 'Script.php' ?>

        </body>
    </html>

    <?php
} else {
    header("location:Index.php");
}
?>



