<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if ($_SESSION['Log'] == "ORA") {
    ?>
    <?php

    $month = $depart = "";

    require('fpdf.php');

    class PDF extends FPDF {

// Page header
        function Header() {


// Logo
            $this->Image('image/kcet.png', 100, 6, 100, 15);
            // Arial bold 15
            $this->Ln(20);
        }

// Page footer
        function Footer() {
            // Position at 1.5 cm from bottom
            $this->SetY(-10);
            $this->SetX(0);

            // Arial italic 8
            $this->SetFont('Arial', 'I', 8);
            // Page number
            $this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'C');


            date_default_timezone_set('Asia/Kolkata');
            $date = date('d-m-Y h:i:sa');
            // Position at 1.5 cm from bottom
            $this->SetY(-11);
            $this->SetX(140);
            // Arial italic 8
            $this->SetFont('Arial', 'B', 11);
            $this->Cell(0, 0, $date, 0, 0, 'C');
        }

    }

// Instanciation of inherited class
    $pdf = new PDF();
    $pdf->AddPage('L', 'A4');

//Fields Name position
    $Y_Fields_Name_position = 30;
//Table position, under Fields Name
    $Y_Table_Position = 36;

//First create each Field Name
//Gray color filling each Field Name box
    $pdf->SetFillColor(232, 232, 232);
//Bold Font for Field Name
    $pdf->SetFont('Arial', 'B', 8);
    $pdf->SetY($Y_Fields_Name_position);
    $pdf->SetX(5);
    $pdf->Cell(15, 6, 'S.N0', 1, 0, 'L', 1);
    $pdf->SetX(20);
    $pdf->Cell(30, 6, 'Abstract ID', 1, 0, 'L', 1);
    $pdf->SetX(50);
    $pdf->Cell(60, 6, 'Name', 1, 0, 'L', 1);
    $pdf->SetX(110);
    $pdf->Cell(100, 6, 'Title', 1, 0, 'L', 1);
    $pdf->SetX(210);
    $pdf->Cell(85, 6, 'College', 1, 0, 'L', 1);
    $pdf->Ln();
    $sno = 1;

//Connect to your database
    include("dbconnect.php");
//Select the Products you want to show in your PDF file
    $query = "select * from register where DayOne='present'";
    $sql = $conn->query($query);
    $number_of_records = $sql->num_rows;

    while ($row = $sql->fetch_assoc()) {
        $abid = $row['AbstractCode'];
        $name = $row['UserName'];
        $title = $row['Title'];
        $college = $row['College'];
//Now show the 3 columns
        $pdf->SetFont('Arial', '', 8);
        $pdf->SetY($Y_Table_Position);
        $pdf->SetX(5);
        $pdf->MultiCell(15, 6, $sno, 1);
        $pdf->SetY($Y_Table_Position);
        $pdf->SetX(20);
        $pdf->MultiCell(30, 6, $abid, 1);
        $pdf->SetY($Y_Table_Position);
        $pdf->SetX(50);
        $pdf->MultiCell(60, 6, $name, 1);
        $pdf->SetY($Y_Table_Position);
        $pdf->SetX(110);
        $pdf->MultiCell(100, 6, $title, 1);
        $pdf->SetY($Y_Table_Position);
        $pdf->SetX(210);
        $pdf->MultiCell(85, 6, $college, 1);
        $pdf->SetY($Y_Table_Position);




        $Y_Table_Position += 12;
        $sno++;



        if ($Y_Table_Position >= 180) {
            $pdf->AddPage('L', 'A4');

//Fields Name position
            $Y_Fields_Name_position = 30;
//Table position, under Fields Name
            $Y_Table_Position = 36;
        }
    }

//For each row, add the field to the corresponding column
    $pdf->Output();
    mysqli_close($conn);
    ?>


    <?php

} else {
    header("location:Index.php");
}?>