<div class="navbar-default sidebar" role="navigation">
    <div class="sidebar-nav navbar-collapse">
        <ul class="nav" id="side-menu">
            <li class="sidebar-search">
                <div class="input-group custom-search-form">

                </div>
                <!-- /input-group -->
            </li>
            <li><a href="Home.php"><i class="fa fa-home fa-fw"></i> HOME</a></li>

            <li>
                <a href="GenerateQR.php"><i class="fa fa-qrcode fa-fw"></i> Generate QR</a>
            </li>
            <li>
                <a href="Attendance.php"><i class="fa fa-hand-paper-o fa-fw"></i> Attendance</a>
            </li>
            <li>
                <a href="Lunch.php"><i class="fa fa-coffee fa-fw"></i> Lunch</a>
            </li>
            <li>
                <a href="Report.php"><i class="fa fa-print fa-fw"></i> Report
                </a>
            </li>

        </ul>
        <!-- /.nav-second-level -->

    </div>
    <!-- /.sidebar-collapse -->
</div>