<?php
$error = "";
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (isset($_POST['login'])) {
    $username = $_POST['email'];
    $password = $_POST['password'];
    if ($username == "ORA-2K18" && $password == "12345678") {
        $_SESSION['Log'] = "ORA";
        $error = "LogIn Success";
        header("location:Home.php");
    } else {
        $error = "Please Try Again";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include 'Style.php' ?>
    </head>
    <body>

        <div id="wrapper">

            <!-- Navigation -->
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <?php include 'NavBarOUT.php'; ?>
                <!-- /.navbar-static-side -->
            </nav>

            <!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-1"></div>
                        <div class="col-lg-4">
                            <h1 class="page-header">ORA - 2K18 </h1>


                            <div class="login-panel panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title">Please Sign In</h3>
                                </div>
                                <div class="panel-body">
                                    <?php if (!empty($_SESSION['error']) || !empty($error)) { ?>   <div class="alert alert-success alert-dismissable">
                                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                            <?php
                                            echo $error;
                                            unset($_SESSION['error']);
                                            ?> </div> <?php } ?>

                                    <form role="form" action="Index.php" method="post">
                                        <fieldset>
                                            <div class="form-group">
                                                <input class="form-control" placeholder="User Name" name="email" type="text" autofocus>
                                            </div>
                                            <div class="form-group">
                                                <input class="form-control" placeholder="Password" name="password" type="password" value="">
                                            </div>
                                            <!-- Change this to a button or input when using this as a form -->
                                            <button class="btn btn-lg btn-success btn-block" name="login">Login</button>
                                        </fieldset>
                                    </form>
                                </div>
                            </div>

                        </div> 
                        <!-- /.col-lg-12 -->
                        <div class="col-lg-4"></div>
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->

        </div>
        <!-- /#wrapper -->
        <?php include 'Script.php' ?>

    </body>
</html>
