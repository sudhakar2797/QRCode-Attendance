<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<div class="navbar-header">
    <a class="navbar-brand" href="Index.php"><i class="fa fa-leaf"></i>&nbsp;&nbsp;ORA</a>
</div>

<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
    <span class="sr-only">Toggle navigation</span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
</button>

<ul class="nav navbar-right navbar-top-links">
    <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
            <i class="fa fa-user fa-fw"></i> <?php echo $_SESSION['Log'] . ' - '; ?>Admin <b class="caret"></b>
        </a>
        <ul class="dropdown-menu dropdown-user">

            <li class="divider"></li>
            <li><a href="LogOut.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
            </li>
        </ul>
    </li>
</ul>